                THE DEVIL IN THE DETAILS                 
    A Tutorial Review on Some Undervalued Aspects of 
        Density Functional Theory Calculations.
               P. Morgante, R. Peverati

Each folder includes all the geometries needed to run calculations.

Experience_01: Applying DFT to Organic Chemistry - Part A.
Experience_02: Applying DFT to Organic Chemistry - Part B.
Experience_03: Difficult Cases for DFT.
Experience_04: Basis Set Incompleteness Error.
Experience_05: Basis Set Superposition Error
Experience_06: Review of Modern Basis Sets
Experience_07: Why is the B3LYP/6-31G* Level of Theory so Successful?
Experience_08: Integration Grids 1: The Argon dimer.
Experience_09: Integration Grids 2: The Case of But-2-yne.
Experience_10: Stability Analysis and Transition Metals.
Experience_11: Comparison with Experimental Results.
Experience_12: Final Review.
                                                  
